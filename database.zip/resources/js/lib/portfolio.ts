export type PortfolioProject = {
    id: string;
    category: 'Aplicaciones' | 'Sitios web' | 'Diseños';
    title: string;
    subtitle: string;
    description: string;
    tags: string[];
    status: string;
    images: string[];
    imageType: 'captura' | 'mockup' | 'exploración';
    url?: string;
    preview: 'hotel' | 'restaurant' | 'sports' | 'brand';
    note: string;
};

export const projects: PortfolioProject[] = [
    {
        id: 'buenaventura',
        category: 'Aplicaciones',
        title: 'Tecnología para un grupo hotelero.',
        subtitle: 'Grupo Buenaventura · Sistemas web',
        description:
            'Desarrollo de aplicaciones para Buenaventura Grand, Villa Premiere y Hacienda Buenaventura. Incluye el módulo de control de documentos de cuentas por pagar y sistemas que funcionan dentro de los hoteles.',
        tags: ['Hotelería', 'Aplicaciones web'],
        status: 'Portal público + sistemas internos',
        imageType: 'captura',
        images: [
            '/images/projects/buenaventura.png',
            '/images/projects/buenaventura-logo.png',
        ],
        url: 'https://cxp.buenaventurahoteles.com/',
        preview: 'hotel',
        note: 'La captura muestra el módulo público de acceso para las propiedades del grupo.',
    },
    {
        id: 'meson-de-mita',
        category: 'Sitios web',
        title: 'La experiencia comienza en la web.',
        subtitle: 'Hotel Mesón de Mita · Sitio web',
        description:
            'Un sitio para descubrir el Hotel Mesón de Mita: habitaciones, servicios, promociones y una experiencia frente al mar en Punta de Mita.',
        tags: ['Hotelería', 'Sitio web'],
        status: 'Sitio público',
        imageType: 'captura',
        images: [
            '/images/projects/meson-de-mita.png',
            '/images/projects/meson-de-mita-logo.png',
        ],
        url: 'https://hotelmesondemita.com/',
        preview: 'hotel',
        note: 'Captura del sitio público de Hotel Mesón de Mita, con navegación y módulo de reservaciones.',
    },
    {
        id: 'little-tokyo',
        category: 'Aplicaciones',
        title: 'Detrás de una gran experiencia.',
        subtitle: 'Little Tokyo · Administración',
        description:
            'Una aplicación de administración para el restaurante Little Tokyo en Guadalajara. El sistema cuenta con acceso privado y se presenta mediante un mockup visual de referencia.',
        tags: ['Restaurantes', 'Administración'],
        status: 'Acceso privado',
        imageType: 'mockup',
        images: [
            '/images/projects/little-tokyo.png',
            '/images/projects/little-tokyo-logo.png',
        ],
        preview: 'restaurant',
        note: 'Mockup visual de referencia para presentar el sistema sin exponer información privada.',
    },
    {
        id: 'strataz',
        category: 'Aplicaciones',
        title: 'Datos deportivos, otra perspectiva.',
        subtitle: 'Strataz · Plataforma de análisis deportivo',
        description:
            'Una plataforma para visualizar estadísticas deportivas en vivo y explorar análisis potenciados con inteligencia artificial. Un proyecto para una startup que aún no se ha publicado.',
        tags: ['Estadísticas en vivo', 'Inteligencia artificial'],
        status: 'Proyecto en preparación',
        imageType: 'mockup',
        images: [
            '/images/projects/strataz.png',
            '/images/projects/strataz-logo.png',
        ],
        preview: 'sports',
        note: 'Mockup visual de referencia; la plataforma todavía no se encuentra publicada.',
    },
    {
        id: 'pixelperfect',
        category: 'Diseños',
        title: 'Una identidad que se siente propia.',
        subtitle: 'PixelPerfect · Identidad y experiencia web',
        description:
            'La dirección visual de PixelPerfect: tipografía de alto contraste, acentos morados y verde lima, y una página de inicio que da protagonismo a lo esencial.',
        tags: ['Diseño web', 'Identidad visual'],
        status: 'Proyecto propio',
        imageType: 'exploración',
        images: [
            '/images/projects/pixelperfect.png',
            '/images/projects/pixelperfect-logo.png',
        ],
        preview: 'brand',
        note: 'Captura de exploración visual basada en la identidad de PixelPerfect.',
    },
];

export const companies = [
    {
        name: 'Grupo Hotelero Buenaventura',
        sector: 'Hotelería',
        project: 'buenaventura',
        mark: 'HB',
        tone: 'navy',
        logo: '/images/projects/buenaventura-logo.png',
        image: '/images/projects/buenaventura.png',
        imageAlt:
            'Módulo de control de documentos de cuentas por pagar de Hoteles Buenaventura',
    },
    {
        name: 'Mesón de Mita',
        sector: 'Hotelería',
        project: 'meson-de-mita',
        mark: 'MM',
        tone: 'sunset',
        logo: '/images/projects/meson-de-mita-logo.png',
        image: '/images/projects/meson-de-mita.png',
        imageAlt: 'Sitio web de Hotel Mesón de Mita',
    },
    {
        name: 'Little Tokyo',
        sector: 'Restaurantes',
        project: 'little-tokyo',
        mark: 'LT',
        tone: 'sakura',
        logo: '/images/projects/little-tokyo-logo.png',
        image: '/images/projects/little-tokyo.png',
        imageAlt: 'Mockup del sistema de administración de Little Tokyo',
    },
    {
        name: 'Strataz',
        sector: 'Startup deportiva',
        project: 'strataz',
        mark: 'S',
        tone: 'violet',
        logo: '/images/projects/strataz-logo.png',
        image: '/images/projects/strataz.png',
        imageAlt: 'Mockup de la plataforma de análisis deportivo Strataz',
    },
];
